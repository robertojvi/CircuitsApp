package com.example.fiberTower;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FiberTowerApplicationTests {

	@Test
	void contextLoads() {
	}

}
